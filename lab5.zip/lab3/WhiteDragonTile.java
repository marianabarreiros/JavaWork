//done done
import java.awt.*;
import javax.swing.JFrame;

public class WhiteDragonTile extends Tile
{
	public String toString()
	{
		return "White Dragon";
	}
   	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Stroke blocks = new BasicStroke(4, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_BEVEL, 
				0, new float[]{7, 14}, 0);
		g.setColor(Color.BLUE);
		g.drawRect(29, 6+2, 54, 54);
		g.drawRect(33, 6+6, 47, 47);
		Graphics2D g2 = (Graphics2D)g;
		g2.setStroke(blocks);
		g2.drawRect(31, 11, 51, 51);		
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("White Dragon Tile");

		frame.add(new WhiteDragonTile());

		frame.pack();
		frame.setVisible(true);
	}
}