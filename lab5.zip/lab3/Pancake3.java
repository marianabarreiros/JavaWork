//done
import java.awt.*;
public class Pancake3 extends Circle
{
	public Color color;	
	public Pancake3( int x,  int y, Color color) 
	{
		super(x, y, color);
      this.color = color;
	}
	public void draw(Graphics g)
	{
   	g.setColor(color);
		g.fillOval(x, y, 20, 20);
		g.setColor(Color.WHITE);
		g.drawLine(x+3, y+3, x+17, y+17);
		g.drawLine(x+17, y+3, x+3, y+17);   
	}
}