//DONE
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
abstract public class Tile extends JPanel
{
	public 	final static Color TOP			= new Color(255, 230, 185);
	public 	final static Color		TOP2	= new Color(255, 251, 241);
   public static Polygon tSide;
   public static Polygon tSide2;
	public static Polygon tBottom;
	public static Polygon tMiddle;
	public	final static Dimension	size 		= new Dimension(92, 98);
	private static int[] xMiddle = {10, 10, 20, 20};
	private static int[] yMiddle = {80, 10, 0, 70};
	private static int[] xSide = {80, 10, 0, 70};
	private static int[] ySide = {80, 80, 90, 90};
	private static int[] xSide2 = {90, 20, 10, 80};
	private static int[] ySide2 = {70, 70, 80, 80};
   private static int[] xPoints = {0, 0, 10, 10};
	private static int[] yPoints = {90, 20, 10, 80};
	protected static HashMap<String, String> chineseChars = new HashMap<String, String>();	
	static
	{
   	tSide = new Polygon(xSide, ySide, xPoints.length);
		tSide2 = new Polygon(xSide2, ySide2, xPoints.length);
		tBottom = new Polygon(xPoints, yPoints, xPoints.length);
		tMiddle = new Polygon(xMiddle, yMiddle, xPoints.length);
		chineseChars.put("1", "\u4E00");
		chineseChars.put("2", "\u4E8C");
		chineseChars.put("3", "\u4E09");
		chineseChars.put("4", "\u56DB");
		chineseChars.put("5", "\u4E94");
		chineseChars.put("6", "\u516D");
		chineseChars.put("7", "\u4E03");
		chineseChars.put("8", "\u516B");
		chineseChars.put("9", "\u4E5D");
		chineseChars.put("N", "\u5317");
		chineseChars.put("E", "\u6771");
		chineseChars.put("W", "\u897F");
		chineseChars.put("S", "\u5357");
		chineseChars.put("C", "\u4E2D");
		chineseChars.put("F", "\u767C");
		chineseChars.put("wan", "\u842C");
}
public boolean matches(Tile other)
{
      if (this == other)
            return true;
      if (other == null)
            return false;
      return getClass() == other.getClass();
}
	public Tile()
	{
		setPreferredSize(size);
}
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D	g2 = (Graphics2D)g;
		GradientPaint	grad = new GradientPaint(0, 70, Color.GREEN,70, 0, Color.GREEN, true);
		g2.setPaint(grad);
		g.fillPolygon(tBottom);
		g.fillPolygon(tSide);
		GradientPaint gradTop = new GradientPaint(20, 70, TOP2,70, 0, TOP, false);
		g2.setPaint(gradTop);
		g.fillRect(20, 0, 70, 70);
		g.fillPolygon(tMiddle);
		g.fillPolygon(tSide2);
		g2.setPaint(Color.BLACK);
		g.drawPolygon(tBottom);
		g.drawPolygon(tMiddle);
		g.drawPolygon(tSide);
		g.drawPolygon(tSide2);
		g.drawRect(20, 0, 70, 70);      
}
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Tile");
		frame.pack();
		frame.setVisible(true);
	}
}