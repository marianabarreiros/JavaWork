import java.awt.Color;
import java.awt.Graphics;


public class Bamboo 
{
	private Color color;
	BambooTile bt;
	private int x;
	private int y;
	public void draw(Graphics g)
	{
		
	}
	public void draw2(Graphics g)
	{
		
}
}