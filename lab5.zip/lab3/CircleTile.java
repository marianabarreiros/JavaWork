//done Done Done
import java.awt.*;
import javax.swing.JFrame;


public class CircleTile extends RankTile
{
	final Circle circles[] = new Circle[9]; // array of 9 circles
   	final Circle2 circles2[] = new Circle2[9]; // array of 9 circles

	public CircleTile(int rank)
	{
		super(rank);
		setToolTipText(toString());
		switch(rank){
      
		case 1:
			circles[0] = new Pancake( 50, 30, Color.RED);
			break;
         
		case 2:
			circles[0] = new Pancake2(45, 5, Color.GREEN);
			circles[1] = new Pancake2(45, 35 , Color.RED);
			break;
      
		case 3:
			circles[0] = new Pancake3(25, 5, Color.BLUE);
			circles[1] = new Pancake3(46, 27, Color.RED);
			circles[2] = new Pancake3(70, 50, Color.GREEN);
			break;
         
		case 4:
			circles[0] = new Pancake2(33, 10, Color.BLUE);
			circles[1] = new Pancake2(33, 40, Color.GREEN);
			circles[2] = new Pancake2(60, 10, Color.GREEN);
			circles[3] = new Pancake2(60, 40, Color.BLUE);
			break;
         
		case 5:
			circles[0] = new Pancake3(25, 5, Color.BLUE);
			circles[1] = new Pancake3(50, 30, Color.RED);
			circles[2] = new Pancake3(68, 50, Color.BLUE);
			circles[3] = new Pancake3(68, 5, Color.GREEN);
			circles[4] = new Pancake3(25, 50, Color.GREEN);
			break;
         
		case 6:
			circles[0] = new Pancake3(33, 5, Color.GREEN);
			circles[1] = new Pancake3(65, 5, Color.GREEN);
			circles[2] = new Pancake3(33, 30, Color.RED);
			circles[3] = new Pancake3(65, 30, Color.RED);
			circles[4] = new Pancake3(33, 50, Color.RED);
			circles[5] = new Pancake3(65, 50, Color.RED);
			break;
         
		case 7:
			circles[0] = new Circle(26, 5, Color.GREEN);
			circles[1] = new Circle(50, 15, Color.GREEN);
			circles[2] = new Circle(67, 25, Color.GREEN);
			circles[3] = new Circle(33, 40, Color.RED);
			circles[4] = new Circle(63, 40, Color.RED);
			circles[5] = new Circle(33, 55, Color.RED);
			circles[6] = new Circle(63, 55, Color.RED);
			break;
         
		case 8:
			circles[0] = new Circle(33, 2, Color.BLUE);
			circles[1] = new Circle(61, 2, Color.BLUE);
			circles[2] = new Circle(33, 21, Color.BLUE);
			circles[3] = new Circle(61, 21, Color.BLUE);
			circles[4] = new Circle(33, 40, Color.BLUE);
			circles[5] = new Circle(61, 40, Color.BLUE);
			circles[6] = new Circle(61, 54, Color.BLUE);
			circles[7] = new Circle(33, 54, Color.BLUE);
			break;
         
		case 9:
			circles[0] = new Pancake3(22, 3, Color.GREEN);
			circles[1] = new Pancake3(47, 3, Color.GREEN);
			circles[2] = new Pancake3(70, 3, Color.GREEN);
			circles[3] = new Pancake3(22, 27, Color.RED);
			circles[4] = new Pancake3(47, 27, Color.RED);
			circles[5] = new Pancake3(70, 27, Color.RED);
			circles[6] = new Pancake3(22, 51, Color.BLUE);
			circles[7] = new Pancake3(47, 51, Color.BLUE);
			circles[8] = new Pancake3(70, 51, Color.BLUE);
			break;
		}
	}

	@Override
	public String toString()
	{
		return "Circle " + rank ;
	}
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		for (Circle c : circles)
			if (c != null)
				c.draw(g);
  //          c.draw2(g);
	}
		public void paintComponent2(Graphics g)
	{
		super.paintComponent(g);
		for (Circle2 c : circles2)
			if (c != null)
			//	c.draw(g);
            c.draw(g);
	}
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Circle Tiles");

		frame.add(new CircleTile(1));
		frame.add(new CircleTile(2));
		frame.add(new CircleTile(3));
		frame.add(new CircleTile(4));
		frame.add(new CircleTile(5));
		frame.add(new CircleTile(6));
		frame.add(new CircleTile(7));
		frame.add(new CircleTile(8));
		frame.add(new CircleTile(9));

		frame.pack();
		frame.setVisible(true);
	}
}