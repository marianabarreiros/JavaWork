import java.awt.*;
import java.awt.image.ImageObserver;
import javax.swing.*;
public class FlowerTile extends PictureTile
{


	private Image Plum = 	new ImageIcon(this.getClass().getResource("/images/Plum.png")).getImage();
	private Image Bamboo = new ImageIcon(this.getClass().getResource("/images/Bamboo.png")).getImage();
	private Image Orchid = new ImageIcon(this.getClass().getResource("/images/Orchid.png")).getImage();
   private Image Chrysanthemum = new ImageIcon(this.getClass().getResource("/images/Chrysanthemum.png")).getImage();
	
   	public FlowerTile(String name)
   {
		super(name);
	}
   
   
   @Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		switch(name){
      
            		case "Bamboo":
			g.drawImage(Bamboo, 31, 3+2, this);
			break;   
      		case "Orchid":
			g.drawImage(Orchid, 23, 3+2, this);
			break;
		case "Chrysanthemum":
			g.drawImage(Chrysanthemum, 23, 3+2, this);
			break;


		case "Plum":
			g.drawImage(Plum, 29, 3+2, this);
			break;

		}
	}
   
   
   
   
   	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Flower Tiles");

		frame.add(new FlowerTile("Chrysanthemum"));
		frame.add(new FlowerTile("Orchid"));
		frame.add(new FlowerTile("Plum"));
		frame.add(new FlowerTile("Bamboo"));

		frame.pack();
		frame.setVisible(true);
	}
   
   
   
   
   
   
   
}