//Done done
import java.awt.*;
import javax.swing.*;
public class SeasonTile extends PictureTile
{
	private Image Fall = new ImageIcon(this.getClass().getResource("/images/Fall.png")).getImage();
   private Image Winter = new ImageIcon(this.getClass().getResource("/images/Winter.png")).getImage();
	private Image Summer = new ImageIcon(this.getClass().getResource("/images/Summer.png")).getImage();
   private Image Spring = new ImageIcon(this.getClass().getResource("/images/Spring.png")).getImage();
	public SeasonTile(String name)
	{
		super(name);
	}
   
   
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		switch(name){
      		case "Summer":
			g.drawImage(Summer, 25, 6, this);
			break;
      		case "Winter":
			g.drawImage(Winter, 24, 6, this);
			break;
		case "Spring":
			g.drawImage(Spring, 24, 11, this);
			break;

		case "Fall":
			g.drawImage(Fall, 24, 6, this);
			break;

		}
	}
   	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Season Tiles");

		frame.add(new SeasonTile("Spring"));
		frame.add(new SeasonTile("Summer"));
		frame.add(new SeasonTile("Fall"));
		frame.add(new SeasonTile("Winter"));

		frame.pack();
		frame.setVisible(true);
	}

}