//done
import java.awt.*;


public class Circle
{
	private Color color;	
	public int x;
	public int y;
	public Circle(int x, int y, Color color) 
	{
		super();
      this.color = color;
      this.y = y;
		this.x = x;
	}
	// to change the size of the circle and the line
	public void draw(Graphics g)
	{
		g.setColor(color);
		g.fillOval(x, y, 12 , 12);
		g.setColor(Color.WHITE);
		g.drawLine(x+2+2, y+2+2, x+4+4, y+4+4);
		g.drawLine(x+4+4, y+2+2, x+2+2, y+4+4);
	}
   
	public void draw2(Graphics g)
	{
		g.setColor(color);
		g.fillOval(x, y, 24 , 24);
	}
   
}