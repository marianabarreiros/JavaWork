//done Done
import java.awt.*;
public class Pancake extends Circle
{
	public Pancake(int x, int y, Color color) 
	{
		super(x, y, color);
	}
	public void draw(Graphics g)
	{
		g.setColor(Color.GREEN);
		g.fillOval(31, 11, 52, 52);
		g.setColor(Color.WHITE);
		super.draw(g);
		g.setColor(Color.BLACK);
		g.drawOval(31, 11, 52, 52);
		Graphics2D	g2 = (Graphics2D)g;
		g2.setColor(Color.WHITE);
		g2.setStroke(new BasicStroke(4.1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER, 5.1f, new float[] {0.6f, 7.1f}, 10.0f));
		g2.drawOval(37, 14, 41, 41);
		
	}
}