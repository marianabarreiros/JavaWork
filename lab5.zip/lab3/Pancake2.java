//done Done
import java.awt.*;
public class Pancake2 extends Circle

{
	public Color color;	
	public Pancake2( int x,  int y, Color color) 
	{
		super(x, y, color);
      this.color = color;
	}
	public void draw(Graphics g)
	{
   	g.setColor(color);
		g.fillOval(x, y, 24 , 24);
		g.setColor(Color.WHITE);
		g.drawLine(x+2, y+2, x+22, y+22);
		g.drawLine(x+22, y+2, x+2, y+22);
	}
}