import java.awt.*;
//not working

public class Circle2
{
	public Color color;	
	public int x;
	public int y;
	public Circle2(int x, int y, Color color) 
	{
		super();
      this.color = color;
      this.y = y;
		this.x = x;
	}
	// to change the size of the circle and the line
	public void draw(Graphics g)
	{
		g.setColor(color);
		g.fillOval(x, y, 12 , 12);
//		g.setColor(Color.WHITE);
		//g.drawLine(x+4, y+4, x+8, y+8);
		//g.drawLine(x+8, y+4, x+4, y+8);
	}
   
	public void draw2(Graphics g)
	{
		g.setColor(color);
      		g.fillOval(x, y, 12 , 12);

//		g.setColor(Color.WHITE);
		//g.drawLine(x+4, y+4, x+8, y+8);
		//g.drawLine(x+8, y+4, x+4, y+8);
	}
   
}