import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class BambooTile extends RankTile
{
public BambooTile(int rank)
{
      super(rank);
}
public String toString()
{
      return "Bamboo " + rank;
}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		switch(rank){
      case 1:
      //not working
      break;
		case 2:
			drawBamboo(g, 50, 12, Color.BLUE);
			drawBamboo(g, 49, 34, Color.GREEN);
			break;
		case 3:
			drawBamboo(g, 50, 12, Color.BLUE);
			drawBamboo(g, 35, 35, Color.GREEN);
			drawBamboo(g, 64, 35, Color.GREEN);
			break;
		case 4:
			drawBamboo(g, 34, 12, Color.BLUE);
			drawBamboo(g, 35, 35, Color.GREEN);
			drawBamboo(g, 64, 12, Color.GREEN);
			drawBamboo(g, 64, 35, Color.BLUE);
			break;
		case 5:
			drawBamboo(g, 29, 12, Color.GREEN);
			drawBamboo(g, 29, 34, Color.BLUE);
			drawBamboo(g, 50, 25, Color.RED);
			drawBamboo(g, 71, 12, Color.BLUE);
			drawBamboo(g, 71, 34, Color.GREEN);
			break;
		case 6:
			drawBamboo(g, 28, 12, Color.GREEN);
			drawBamboo(g, 28, 35, Color.BLUE);
			drawBamboo(g, 50, 12, Color.GREEN);
			drawBamboo(g, 50, 34, Color.BLUE);
			drawBamboo(g, 71, 12, Color.GREEN);
			drawBamboo(g, 71, 35, Color.BLUE);
			break;
		case 7:
			drawBamboo(g, 50, 3, Color.RED);
			drawBamboo(g, 29, 25, Color.GREEN);
			drawBamboo(g, 29, 46, Color.BLUE);
			drawBamboo(g, 50, 25, Color.GREEN);
			drawBamboo(g, 50, 46, Color.BLUE);
			drawBamboo(g, 71, 25, Color.GREEN);
			drawBamboo(g, 71, 46, Color.BLUE);
			break;
         //extra credit
		case 8:     
			drawBamboo(g, 25, 13, Color.GREEN);
			drawBamboo(g, 25, 34, Color.BLUE);
			drawBamboo(g, 78, 13, Color.GREEN);
			drawBamboo(g, 78, 34, Color.BLUE);
         Graphics2D g2d = (Graphics2D)g;
         g2d.rotate(Math.toRadians(45));
			drawBamboo(g, 45, -27, Color.GREEN);
                //      g2d.rotate(Math.toRadians(45));
			drawBamboo(g, 73, -27, Color.BLUE);         
         g2d.rotate(Math.toRadians(90));
  			drawBamboo(g, -35, -74, Color.GREEN);
			drawBamboo(g, -5, -74, Color.BLUE);      
			break;
		case 9:
			drawBamboo(g, 29, 3, Color.RED);
			drawBamboo(g, 29, 25, Color.RED);
			drawBamboo(g, 50, 3, Color.BLUE);
			drawBamboo(g, 50, 25, Color.BLUE);
			drawBamboo(g, 71, 3, Color.GREEN);
			drawBamboo(g, 71, 25, Color.GREEN);
			drawBamboo(g, 29, 46, Color.RED);
			drawBamboo(g, 49, 46, Color.BLUE);
			drawBamboo(g, 71, 46, Color.GREEN);
			break;
		}
		
	}
	
	public void drawBamboo(Graphics g, int x, int y, Color color)
	{
		g.setColor(color);
		g.fillOval(x, y, 8 + 2, 5);
		g.fillOval(x, y+8 + 8, 2 + 8, 5);
		g.fillRoundRect(x+1+1, y+1, 10 - 4, 10 + 10, 2, 1 + 1);
		g.setColor(Color.WHITE);
		g.drawLine(x+3+2, y+1+1, x+3+2, y+7+7+4);
		g.setColor(color);
		g.fillOval(x, y+2+5, 10, 4+1);
	}
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Bamboo Tiles");

		frame.add(new BambooTile(2));
		frame.add(new BambooTile(3));
		frame.add(new BambooTile(4));
		frame.add(new BambooTile(5));
		frame.add(new BambooTile(6));
		frame.add(new BambooTile(7));
		frame.add(new BambooTile(8));
		frame.add(new BambooTile(9));

		frame.pack();
		frame.setVisible(true);
	}
	public void draw(Graphics g)
	{	
   }
}