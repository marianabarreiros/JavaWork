//Done Done
import java.util.HashMap;              // HashMap version
import javax.swing.*;
import java.awt.*;


public class CharacterTile extends Tile
{
private  static     HashMap<Character, String> labels = new 
HashMap<>();     // HashMap version
protected  char  symbol;
private String ChineseLetter;
public CharacterTile(char symbol)
{
		//super(symbol);
		setToolTipText(toString());
      ChineseLetter = Tile.chineseChars.get(Character.toString(symbol));
      this.symbol = symbol;
}
	@Override
	public void paintComponent(Graphics g)
	{
   // for numbers
		super.paintComponent(g); 
		if (symbol >= '1' && symbol <= '9') 
		{
			createSymbol(g, Color.BLACK);
		}  
      //for letters
      if (symbol == 'N' || symbol == 'E' ||symbol == 'S' ||symbol == 'W')
      {
			createSymbol(g, Color.BLACK);
      }
      if (symbol == 'F'){
      			createSymbol(g, Color.GREEN);
      }
            if (symbol == 'C'){
      			createSymbol(g, Color.RED);
      }

}

//delete
	//@Override
	public void paintComponent2(Graphics gg)
	{
	//	super.paintComponent2(gg);

		gg.setColor(Color.BLUE);
		gg.drawString(Character.toString(symbol), 85, 45);

      
      if (symbol == 'N' || symbol == 'E' ||symbol == 'S' ||symbol == 'W' ||symbol == 'C' ||symbol == 'F')
      {
			createSymbol2(gg, Color.BLUE);

      }
}
//

//@Override
// creating the symbol
	public void createSymbol(Graphics g, Color c) 
	{
		Font font = g.getFont();
		FontMetrics fontMetrics = g.getFontMetrics();
		int width = fontMetrics.stringWidth(ChineseLetter);
		g.setColor(c);
		int width2 = fontMetrics.stringWidth(ChineseLetter);

            if (symbol == 'N' || symbol == 'E' ||symbol == 'S' ||symbol == 'W' ||symbol == 'C' ||symbol == 'F')
      {
      // for the one symbol center
		//	createSymbol2(gg, Color.BLUE);
		font = font.deriveFont(font.getSize2D() * 4F);
		g.setFont(font);
		g.drawString( ChineseLetter, (getWidth() ) / 4, (getHeight() + 125) / 4);
		
      }
      
      
      		if (symbol >= '1' && symbol <= '9') 
		{
      //to show wan and the symbol
      		font = font.deriveFont(font.getSize2D() * 2F);
		g.setFont(font);
		g.drawString( ChineseLetter, (getWidth() - (width - 5)) / 2, (getHeight() + 25) / 4);
		g.setColor(Color.RED);
		g.drawString(Tile.chineseChars.get("wan"), (getWidth() - (width - 5)) / 2, (getHeight() + 25) / 2);
      }
      
}
//delete
	public void createSymbol2(Graphics gg, Color c) 
	{
		Font font = gg.getFont();
		FontMetrics fm = gg.getFontMetrics();
		int width = fm.stringWidth(ChineseLetter);
		
		gg.setColor(c);
		font = font.deriveFont(font.getSize2D() * 2F);
		gg.setFont(font);
		gg.drawString( ChineseLetter, (getWidth() - (width - 5)) / 2, (getHeight() + 25) / 4);
		
		gg.setColor(Color.RED);
	//	gg.drawString(Tile.chineseChars.get("wan"), (getWidth() - (width - 5)) / 2, (getHeight() + 25) / 2);
}
//

public boolean matches(Tile other)
{
      return super.matches(other) && symbol == 
      ((CharacterTile)other).symbol;
     // this.sybmol = symbol;
}
public String toString()
{
      switch (symbol)
      {
            case 'C': return "Red Dragon";
            case 'F': return "Green Dragon";
            case 'N': return "North Wind";
            case 'E': return "East Wind";
            case 'W': return "West Wind";
            case 'S': return "South Wind";
            default : return "Character " + symbol;
      }
}
/*                                  // HashMap version
public String toString()
{
      return labels.get(symbol);
}
static
{
      labels.put('C', "Red Dragon");
      labels.put('F', "Green Dragon");
      labels.put('N', "North Wind");
      labels.put('E', "East Wind");
      labels.put('W', "West Wind");
      labels.put('S', "South Wind");
      for (char c = '1'; c <= '9'; c++)
            labels.put(c, "Character " + c);
}
*/


public static void main(String[] args)
	{
		JFrame		frame = new JFrame();
		JPanel		tiles = new JPanel();
		JScrollPane	scroller = new JScrollPane(tiles);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Character Tiles");
		frame.add(scroller);

		
		tiles.add(new CharacterTile('1'));
		tiles.add(new CharacterTile('2'));
		tiles.add(new CharacterTile('3'));
		tiles.add(new CharacterTile('4'));
		tiles.add(new CharacterTile('5'));
		tiles.add(new CharacterTile('6'));
		tiles.add(new CharacterTile('7'));
		tiles.add(new CharacterTile('8'));
		tiles.add(new CharacterTile('9'));
		tiles.add(new CharacterTile('N'));
		tiles.add(new CharacterTile('E'));
		tiles.add(new CharacterTile('W'));
		tiles.add(new CharacterTile('S'));
		tiles.add(new CharacterTile('C'));
		tiles.add(new CharacterTile('F'));

		frame.pack();
		frame.setVisible(true);
	}

}