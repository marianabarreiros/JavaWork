

public class Bamboo1Tile extends PictureTile 
{

	public Bamboo1Tile()
	{
		super("Sparrow");
		System.out.println("please work");
	}
   
   
   

	public String toString()
	{
		return "Bamboo 1";
	}
}
